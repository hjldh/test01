package iphonesubscription;

import iphonesubscription.config.kafka.KafkaProcessor;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

@Service
public class PolicyHandler{
    @Autowired SubscriptionRepository subscriptionRepository;

    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverPaymentCompleted_Subscribe(@Payload PaymentCompleted paymentCompleted){

        if(!paymentCompleted.validate()) return;

        System.out.println("\n\n##### listener Subscribe : " + paymentCompleted.toJson() + "\n\n");



        // Sample Logic //
        // Subscription subscription = new Subscription();
        // subscriptionRepository.save(subscription);

    }


    @StreamListener(KafkaProcessor.INPUT)
    public void whatever(@Payload String eventString){}


}